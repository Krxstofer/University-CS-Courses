#include <iostream>
#include <iomanip>
#include <string>
#include "noServiceChargeChecking.h"

using namespace std;

class highInterestChecking : public noServiceChargeChecking
{
    public:
        highInterestChecking(int acctNum, string name, double initialBalance)
            : noServiceChargeChecking(acctNum, name, initialBalance)
        {
            // The only difference between the base class noServiceChargeChecking
            // is the values of interest and minimum balance.
            // So no additional functionality needed for this one.

            _InterestRate = 5.0; // Higher interest rate
            _ChecksRemaining = -1; // -1 indicates no limit
            _MinimumBalance = 1000; // Minimum balance
        }

        highInterestChecking(void) {}
};