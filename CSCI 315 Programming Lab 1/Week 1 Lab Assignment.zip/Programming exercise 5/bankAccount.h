#include <iostream>
#include <iomanip>
#include <string>
#pragma once

using namespace std;

class bankAccount
{
    public:
        bankAccount(int acctNum, string name, double initialBalance)
        {
            _AcctNumber = acctNum;
            _Name = name;
            _Balance = initialBalance;
        }
        bankAccount(void) {}

        string getName()
        {
            return _Name;
        }

        int getAcctNumber()
        {
            return _AcctNumber;
        }

        double getBalance()
        {
            return _Balance;
        }

        void deposit(double amount)
        {
            _Balance += amount;
            cout << "$" << amount << " has been deposited to your account" << endl;
        }

        virtual void withdraw(double amount) = 0;
        virtual void printStatement() = 0;
        virtual void printSummary()
        {
            cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
            cout << endl << setw(25) << "" << "Account Summary" << endl << endl;
            cout << setw(25) << "Name: " << _Name << endl;
            cout << setw(25) << "Account #: " << _AcctNumber << endl;
            cout << setw(25) << "Current Balance: $" << _Balance << endl;
        }

    protected:
        string _Name;
        int _AcctNumber;
        double _Balance;
};
