#include <iostream>
#include <iomanip>
#include <string>
#include "savingsAccount.h"

using namespace std;

class highInterestSavings : public savingsAccount
{
    public:
        highInterestSavings(int acctNum, string name, double initialBalance)
            : savingsAccount(acctNum, name, initialBalance)
        {
            _MinimumBalance = 5000;
        }

        highInterestSavings(void) {}

        void withdraw(double amount)
        {
            if (_Balance - amount < 0)
            {
                cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
                return;
            }

            if (_Balance - amount < _MinimumBalance)
            {
                cout << "Declined: Minimum balance requirement prohibits this withdrawal" << endl;
                return;
            }

            _Balance -= amount;
        }

        void printSummary()
        {
            // Use the root base class to print common info
            bankAccount::printSummary();

            cout << setw(25) << "Interest rate: " << _InterestRate << "%" << endl;
            cout << setw(25) << "Minimum Balance: $" << _MinimumBalance << endl << endl;
            cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
        }


    protected:
        double _MinimumBalance;

};
