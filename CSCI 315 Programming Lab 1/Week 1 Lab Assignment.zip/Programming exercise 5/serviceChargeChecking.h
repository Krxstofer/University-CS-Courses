#include <iostream>
#include <iomanip>
#include <string>
#include "checkingAccount.h"

using namespace std;

const int MAX_CHECKS = 5;
const double SVC_CHARGE = 10.0l;

class serviceChargeChecking : public checkingAccount
{
    public:
        serviceChargeChecking(int acctNum, string name, double initialBalance)
            : checkingAccount(acctNum, name, initialBalance)
        {
            _InterestRate = 0; // No interest
            _ChecksRemaining = MAX_CHECKS; // Limit of 5 checks
            _MinimumBalance = 0; // No minimum balance
        }

        serviceChargeChecking(void) {}

        void writeCheck(double amount)
        {
            if (_ChecksRemaining == 0)
            {
                cout << "Declined: No more checks remaining this month" << endl;
                return;
            }

            if (_Balance - amount < 0)
            {
                cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
                return;
            }

            _ChecksRemaining--;
            _Balance -= amount; // Assume check is cashed immediately...

        }

        void printSummary()
        {
            // Use the root base class to print common info
            bankAccount::printSummary();
            cout << setw(25) << "Checks remaining: " << _ChecksRemaining << endl;
            cout << setw(25) << "Monthly service fee: $" << SVC_CHARGE << endl;
            cout << setw(25) << "No interest " << endl;
            cout << setw(25) << "No Minimum Balance " << endl;
            cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
        }
};
