#include <iostream>
#include <iomanip>
#include <string>
#include "bankAccount.h"
#pragma once

using namespace std;

class checkingAccount : public bankAccount
{
    public:
        checkingAccount(int acctNum, string name, double initialBalance)
            : bankAccount(acctNum, name, initialBalance)
        {
        }
        checkingAccount(void) {}

        virtual void writeCheck(double amount) = 0;

        void withdraw(double amount)
        {
            if (_Balance - amount < 0)
            {
                cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
                return;
            }
            if (_Balance - amount < _MinimumBalance)
            {
                cout << "Declined: Minimum balance requirement prohibits this withdrawal" << endl;
                return;
            }
            _Balance -= amount;
        }

        void printStatement()
        {
            printSummary();
            cout << endl << "A full implementation would also print details of a Checking Account Statement here." << endl << endl;
        }

    protected:
        double _InterestRate;
        int _ChecksRemaining;
        double _MinimumBalance;
};
