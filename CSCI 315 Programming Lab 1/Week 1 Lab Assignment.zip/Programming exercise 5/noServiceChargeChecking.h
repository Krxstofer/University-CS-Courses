#include <iostream>
#include <iomanip>
#include <string>
#include "checkingAccount.h"

using namespace std;

class noServiceChargeChecking : public checkingAccount
{
    public:
        noServiceChargeChecking(int acctNum, string name, double initialBalance)
            : checkingAccount(acctNum, name, initialBalance)
        {
            _InterestRate = 2.5; // Some interest rate
            _ChecksRemaining = -1; // -1 indicates no limit
            _MinimumBalance = 500; // Minimum balance

        }

        noServiceChargeChecking(void) {}

        void writeCheck(double amount)
        {
            if (_Balance - amount < 0)
            {
                cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
                return;
            }

            _Balance -= amount; // Assume check is cashed immediately...
        }

        void printSummary()
        {
            // Use the root base class to print common info
            bankAccount::printSummary();
            cout << setw(25) << "Interest rate: " << _InterestRate << "%" << endl;
            cout << setw(25) << "Minimum Balance: $" << _MinimumBalance << endl;
            cout << setw(25) << "Unlimited checks   " << endl;
            cout << setw(25) << "No monthly service fee   " << endl;
            cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
        }

};
